package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private ImageView imageView;
    private Random random;
    private boolean isCanvasCreated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageView);
        paint = new Paint();
        paint.setStrokeWidth(5);
        random = new Random();
    }

    private void createCanvasIfNeeded() {
        if (!isCanvasCreated) {
            int width = imageView.getWidth();
            int height = imageView.getHeight();
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            imageView.setImageBitmap(bitmap);
            isCanvasCreated = true;
        }
    }

    private int getRandomColor() {
        return Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }

    public void onCreateCanvas(View view) {
        createCanvasIfNeeded();
    }

    public void onDrawLines(View view) {
        if (isCanvasCreated) {
            paint.setColor(getRandomColor());
            for (int i = 0; i < 20; i++) {
                int startX = random.nextInt(bitmap.getWidth());
                int startY = random.nextInt(bitmap.getHeight());
                int stopX = random.nextInt(bitmap.getWidth());
                int stopY = random.nextInt(bitmap.getHeight());
                canvas.drawLine(startX, startY, stopX, stopY, paint);
            }
            imageView.invalidate();
        }
    }

    public void onDrawEllipses(View view) {
        if (isCanvasCreated) {
            paint.setColor(getRandomColor());
            for (int i = 0; i < 20; i++) {
                int left = random.nextInt(bitmap.getWidth() / 2);
                int top = random.nextInt(bitmap.getHeight() / 2);
                int right = left + random.nextInt(bitmap.getWidth() - left);
                int bottom = top + random.nextInt(bitmap.getHeight() - top);
                canvas.drawOval(left, top, right, bottom, paint);
            }
            imageView.invalidate();
        }
    }

    public void onDrawRectangles(View view) {
        if (isCanvasCreated) {
            paint.setColor(getRandomColor());
            for (int i = 0; i < 20; i++) {
                int left = random.nextInt(bitmap.getWidth() / 2);
                int top = random.nextInt(bitmap.getHeight() / 2);
                int right = left + random.nextInt(bitmap.getWidth() - left);
                int bottom = top + random.nextInt(bitmap.getHeight() - top);
                canvas.drawRect(left, top, right, bottom, paint);
            }
            imageView.invalidate();
        }
    }

    public void onClearCanvas(View view) {
        if (isCanvasCreated) {
            canvas.drawColor(Color.WHITE);
            imageView.invalidate();
        }
    }
}
