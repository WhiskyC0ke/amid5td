package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class Figura extends View {
    private final Random r = new Random();

    public Figura(Context context) {
        super(context);
    }

    public Figura(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int szer = getWidth();
        int wys = getHeight();
        int szer2 = szer / 2;
        int rozmiar = Math.min(szer2, wys) - 10;
        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setStyle(Paint.Style.FILL);

        CharSequence opis = getContentDescription() != null ? getContentDescription() : "brak";
        p.setColor(Color.GRAY);
        canvas.drawRect(0, 0, szer - 1, wys - 1, p);

        for (int i = 0; i < 10; i++) {
            p.setARGB(255, r.nextInt(256), r.nextInt(256), r.nextInt(256));
            drawShape(canvas, p, opis.toString(), szer2, wys, rozmiar);
        }

        p.setTextSize(40);
        p.setTextAlign(Paint.Align.RIGHT);
        p.setColor(Color.BLUE);
        canvas.drawText(opis.toString(), szer - 20, wys / 2, p);

        super.onDraw(canvas);
    }

    private void drawShape(Canvas canvas, Paint paint, String opis, int szer2, int wys, int rozmiar) {
        int x, y, dx, dy;
        RectF rectF;
        switch (opis) {
            case "kolo":
                dx = r.nextInt(rozmiar);
                x = r.nextInt(szer2 - dx);
                y = r.nextInt(wys - dx);
                canvas.drawCircle(x, y, dx, paint);
                break;
            case "elipsa":
                dx = r.nextInt(rozmiar);
                dy = r.nextInt(rozmiar);
                x = r.nextInt(szer2 - dx);
                y = r.nextInt(wys - dy);
                rectF = new RectF(x, y, x + dx, y + dy);
                canvas.drawOval(rectF, paint);
                break;
            case "prostokat":
                dx = r.nextInt(rozmiar);
                dy = r.nextInt(rozmiar);
                x = r.nextInt(szer2 - dx);
                y = r.nextInt(wys - dy);
                rectF = new RectF(x, y, x + dx, y + dy);
                canvas.drawRect(rectF, paint);
                break;
            case "luk":
                dx = r.nextInt(rozmiar);
                dy = r.nextInt(rozmiar);
                x = r.nextInt(szer2 - dx);
                y = r.nextInt(wys - dy);
                rectF = new RectF(x, y, x + dx, y + dy);
                canvas.drawArc(rectF, r.nextInt(360), r.nextInt(360), false, paint);
                break;
            case "linia":
                x = r.nextInt(szer2);
                y = r.nextInt(wys);
                dx = r.nextInt(szer2);
                dy = r.nextInt(wys);
                canvas.drawLine(x, y, dx, dy, paint);
                break;
        }
    }
}
