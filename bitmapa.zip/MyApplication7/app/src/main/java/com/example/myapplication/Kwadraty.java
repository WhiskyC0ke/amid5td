package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class Kwadraty extends View {
    private final Random generator = new Random();
    private int r, kolory1, kolory2, kolory3;

    public Kwadraty(Context context) {
        super(context);
    }

    public Kwadraty(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    private void losoweWartosci() {
        r = generator.nextInt(200);
        kolory1 = generator.nextInt(256);
        kolory2 = generator.nextInt(256);
        kolory3 = generator.nextInt(256);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int szer = getWidth();
        int wys = getHeight();
        Paint p = new Paint();
        p.setStyle(Paint.Style.FILL);

        for (int i = 0; i < 10; i++) {
            losoweWartosci();
            p.setARGB(255, kolory1, kolory2, kolory3);
            int l = generator.nextInt(szer) + r;
            int k = generator.nextInt(wys) + r;
            int l2 = generator.nextInt(szer) + r;
            int k2 = generator.nextInt(wys) + r;
            canvas.drawRect(l, k, l2, k2, p);
        }

        super.onDraw(canvas);
    }
}
