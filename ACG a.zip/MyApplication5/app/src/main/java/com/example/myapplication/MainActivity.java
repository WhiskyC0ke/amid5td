package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);

        Button buttonLoad = findViewById(R.id.button);
        Button buttonRandomize = findViewById(R.id.button2);

        buttonLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Wczytaj obraz jako Drawable do ImageView
                imageView.setImageResource(R.drawable.example_image);
            }
        });

        buttonRandomize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                randomizeImagePixels();
            }
        });
    }

    private void randomizeImagePixels() {
        Drawable drawable = imageView.getDrawable();
        if (drawable instanceof BitmapDrawable) {
            Bitmap originalBitmap = ((BitmapDrawable) drawable).getBitmap();
            Bitmap modifiedBitmap = randomizePixels(originalBitmap);

            imageView.setImageBitmap(modifiedBitmap);

            // Wyświetl informacje o obrazie
            String info = "Szerokość: " + modifiedBitmap.getWidth() +
                    " Wysokość: " + modifiedBitmap.getHeight() +
                    " Piksele: " + (modifiedBitmap.getWidth() * modifiedBitmap.getHeight());
            textView.setText(info);
        }
    }

    private Bitmap randomizePixels(Bitmap originalBitmap) {
        int width = originalBitmap.getWidth();
        int height = originalBitmap.getHeight();
        Bitmap newBitmap = Bitmap.createBitmap(width, height, originalBitmap.getConfig());

        Random random = new Random();
        int maxOffset = 30;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int pixelColor = originalBitmap.getPixel(x, y);

                int red = Math.min(255, Math.max(0, ((pixelColor >> 16) & 0xFF) + random.nextInt(2 * maxOffset + 1) - maxOffset));
                int green = Math.min(255, Math.max(0, ((pixelColor >> 8) & 0xFF) + random.nextInt(2 * maxOffset + 1) - maxOffset));
                int blue = Math.min(255, Math.max(0, (pixelColor & 0xFF) + random.nextInt(2 * maxOffset + 1) - maxOffset));

                int newPixelColor = (0xFF << 24) | (red << 16) | (green << 8) | blue;
                newBitmap.setPixel(x, y, newPixelColor);
            }
        }
        return newBitmap;
    }
}
